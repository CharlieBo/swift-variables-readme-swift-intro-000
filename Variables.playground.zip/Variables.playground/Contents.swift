var favoriteCharacter = "Jon Snow"
print(favoriteCharacter)

favoriteCharacter = "Tyrion Lannister"
print(favoriteCharacter)

favoriteCharacter = "Khalessi"
print(favoriteCharacter)

var ultimateFavoriteCharacter = "Arya Stark"
print(ultimateFavoriteCharacter)

ultimateFavoriteCharacter = "Daenerys Targaryen"

let GameofThroneChar = "King Thomas"


print(GameofThroneChar)

